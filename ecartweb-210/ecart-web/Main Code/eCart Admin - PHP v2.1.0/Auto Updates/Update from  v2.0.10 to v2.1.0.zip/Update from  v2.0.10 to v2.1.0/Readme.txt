--------------------------------------
	eKart by WRTeam
---------------------------------------
Thanks for showing your love & support
---------------------------------------

Read this before you UPDATE ( Auto Update ) the system code from older version
to newer version than this is for you.
-----------------------------------------------------------------------
Common Steps to update the system from older version to newer version
-----------------------------------------------------------------------
1. Download the updated code from the codecanyon.net
2. Find and locate the 'update' folder
3. upload this 'update' folder into your eKart's Admin Panel's main directory
	
	For example : If your ekart panel is inside `public_html/ekart/` 
					and your panel URL is ekart.wrteam.in
		than update folder should be uploaded like
			`public_html/ekart/update/`
		
4. Now open the just uploaded 'update' folder from any of the browser
	For example : ekart.wrteam.in/update/
	( If you can see the auto update page than folder is uploaded successfully )
5. Now click on 'Update Now to v X.X' button. You'll be asked to confirm the update. Click 'OK'.
6. And That's all your system updated successfully to latest version.

	Note : Please use this Auto Update script only to upgrade your system to the next version only. 
	If you've missed more than one of the updates than do not directly use this script. Find all previous Auto update scripts and 
	update each version one by one.

Still, Have a query or questions visit our site now?
https://wrteam.in

Thanks regards
