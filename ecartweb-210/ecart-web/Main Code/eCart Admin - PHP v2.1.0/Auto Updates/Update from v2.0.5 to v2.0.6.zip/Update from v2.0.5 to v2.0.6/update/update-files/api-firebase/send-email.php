<?php
header('Access-Control-Allow-Origin: *');
	
function send_email($to,$subject,$message){

	include_once '../includes/crud.php';
	$db=new Database();
	$db->connect();
	
	include_once '../includes/functions.php';
    $fn = new functions();
    $system_configs = $fn->get_system_configs();
	
	$app_name = $system_configs['app_name'];
	$from_mail = $system_configs['from_mail'];
	$reply_to = $system_configs['reply_to'];
	
	//send email
	$headers = "From: ".$app_name."<".$from_mail.">\n";
	$headers .= "Reply-To: ".$reply_to."\n";
	$headers .= "MIME-Version: 1.0\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\n";
		if(!mail($to,$subject,$message,$headers))
			return false;
		else
			return true;
}

	
function send_email_with_template($to,$subject,$item_data1,$order_data){
	include_once '../includes/crud.php';
	$db=new Database();
	$db->connect();
	
	include_once '../includes/functions.php';
    $fn = new functions();
    $system_configs = $fn->get_system_configs();
	
	$app_name = $system_configs['app_name'];
	$from_mail = $system_configs['from_mail'];
	$reply_to = $system_configs['reply_to'];
	ob_start(); 
	include 'email-templates/order_receipt.php'; 
	$message = ob_get_contents(); 
	ob_end_clean();
	
	//send email
	$headers = "From: ".$app_name."<".$from_mail.">\n";
	$headers .= "Reply-To: ".$reply_to."\n";
	$headers .= "MIME-Version: 1.0\n";
	$headers .= "Content-Type: text/html; charset=ISO-8859-1\n";
		if(!mail($to,$subject,$message,$headers))
			return false;
		else
			return true;
}
// $message = file_get_contents('email-templates/order_receipt.php');
// $order_data = array('total_amount' => 'Rs6000.0','delivery_charge' => 'Rs20.0','tax_amount' => 'Rs10','discount' => '10(%)','wallet_used' => 'Rs00','final_total' => 'Rs5090','payment_method' => 'COD','address' => 'bhuj');
// // $item_data1[] = array((0) => array('name' => 'Harpic bathroom cleaner lemon','unit' => '500 ml','qty' => '3','subtotal' => '180'));


// $item_data1[] = array((0) => array('name' => 'Harpic bathroom cleaner lemon','unit' => '500 ml','qty' => '3','subtotal' => '180'),(1) => array('name' => 'Palak','unit' => '1 kg','qty' => '2','subtotal' => '180'));

// if(	send_email_with_template("infinitietechnologies03@gmail.com","Order received successfully!!!",$item_data1,$order_data)){
//     echo "success";
// }else{
//     echo "fail";
// }
