<?php
session_start();
error_reporting(true);
$latest_version = "v2.0.9";
/*
*	Update script for eCart PHP Admin Panel from v2.0.8.2 to v2.0.9
*	All Right reserved to WRTeam.in
*	
*/
// sleep(5);
// include "convert-latin1-to-utf8.php";
if (!isset($_SESSION["count"]) && $_SESSION["count"] != "applied") {
	include('../includes/crud.php');
	$db = new Database();
	$db->connect();

    /* adding columns and altering fields in database table */
    $db->sql("ALTER TABLE `orders` ADD `order_note` TEXT NULL DEFAULT NULL AFTER `mobile`; ");
    $db->sql("ALTER TABLE `orders` ADD `order_from` TINYINT(2) NULL DEFAULT '0' AFTER `active_status`;");
    $db->sql("ALTER TABLE `delivery_boys` ADD `order_note` TEXT NULL DEFAULT NULL AFTER `mobile`;");
    $db->sql("ALTER TABLE `category` ADD `row_order` INT(11) NOT NULL DEFAULT '0' AFTER `id`; ");
    $db->sql("ALTER TABLE `category` ADD `web_image` TEXT NOT NULL;");
    $db->sql("CREATE TABLE `social_media` (`id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, `icon` text NOT NULL, `link` text NOT NULL)");
    $db->sql("CREATE TABLE `media` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `name` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `extension` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `type` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `sub_directory` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `size` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , `date_created` TIMESTAMP on update CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
    $db->sql("CREATE TABLE `devices` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `user_id` INT(11) NULL , `fcm_id` VARCHAR(256) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");

    $db->sql("ALTER TABLE `admin` CHANGE `fcm_id` `fcm_id` VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;");
    $db->sql("ALTER TABLE `admin` CHANGE `forgot_password_code` `forgot_password_code` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;");
    
    $db->sql("CREATE TABLE IF NOT EXISTS `updates` (`id` INT(11) NOT NULL AUTO_INCREMENT , `version` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL , PRIMARY KEY (`id`)) ENGINE=InnoDB ");
    $db->sql("SELECT * FROM `updates` where `version`='$latest_version' ");
    $res = $db->getResult();
	if(empty($res)){
        $db->sql("INSERT INTO `updates` (`version`) VALUES ('$latest_version')");
    }
    
    /* admin-app starts here */
    copy('update-files/admin-app/api/api-v1-docs.txt', '../admin-app/api/api-v1-docs.txt');
    copy('update-files/admin-app/api/api-v1.php', '../admin-app/api/api-v1.php');
    copy('update-files/admin-app/api/verify-token.php', '../admin-app/api/verify-token.php');
    /* admin-app ends here */
	
    $zip = new ZipArchive;
	if ($zip->open('update-files/paytm.zip') === TRUE) {
		$zip->extractTo('../');
		$zip->close();
	}

	/* api-firebase starts here */
	copy('update-files/api-firebase/api-docs.txt', '../api-firebase/api-docs.txt');
	copy('update-files/api-firebase/cart.php', '../api-firebase/cart.php');
	copy('update-files/api-firebase/create-razorpay-order.php', '../api-firebase/create-razorpay-order.php');
	copy('update-files/api-firebase/favorites.php', '../api-firebase/favorites.php');
	copy('update-files/api-firebase/get-all-data.php', '../api-firebase/get-all-data.php');
	copy('update-files/api-firebase/get-all-products.php', '../api-firebase/get-all-products.php');
	copy('update-files/api-firebase/get-user-transactions.php', '../api-firebase/get-user-transactions.php');
	copy('update-files/api-firebase/get-areas-by-city-id.php', '../api-firebase/get-areas-by-city-id.php');
	copy('update-files/api-firebase/get-bootstrap-table-data.php', '../api-firebase/get-bootstrap-table-data.php');
	copy('update-files/api-firebase/get-bootstrap-web-category-table-data.php', '../api-firebase/get-bootstrap-web-category-table-data.php');
	copy('update-files/api-firebase/get-categories.php', '../api-firebase/get-categories.php');
	copy('update-files/api-firebase/get-cities.php', '../api-firebase/get-cities.php');
	copy('update-files/api-firebase/get-faqs.php', '../api-firebase/get-faqs.php');
	copy('update-files/api-firebase/get-product-by-id.php', '../api-firebase/get-product-by-id.php');
	copy('update-files/api-firebase/get-products-by-category-id.php', '../api-firebase/get-products-by-category-id.php');
	copy('update-files/api-firebase/get-products-by-subcategory-id.php', '../api-firebase/get-products-by-subcategory-id.php');
	copy('update-files/api-firebase/get-products-offline.php', '../api-firebase/get-products-offline.php');
    copy('update-files/api-firebase/get-similar-products.php', '../api-firebase/get-similar-products.php');
    copy('update-files/api-firebase/get-social-media.php', '../api-firebase/get-social-media.php');
	copy('update-files/api-firebase/get-subcategories-by-category-id.php', '../api-firebase/get-subcategories-by-category-id.php');
	copy('update-files/api-firebase/get-user-data.php', '../api-firebase/get-user-data.php');
	copy('update-files/api-firebase/get-user-transactions.php', '../api-firebase/get-user-transactions.php');
	copy('update-files/api-firebase/get-variants-offline.php', '../api-firebase/get-variants-offline.php');
	copy('update-files/api-firebase/login.php', '../api-firebase/login.php');
	copy('update-files/api-firebase/offer-images.php', '../api-firebase/offer-images.php');
	copy('update-files/api-firebase/order-process.php', '../api-firebase/order-process.php');
	copy('update-files/api-firebase/payment-request.php', '../api-firebase/payment-request.php');
	copy('update-files/api-firebase/products-search.php', '../api-firebase/products-search.php');
	copy('update-files/api-firebase/store-fcm-id.php', '../api-firebase/store-fcm-id.php');
	copy('update-files/api-firebase/remove-fcm-id.php', '../api-firebase/remove-fcm-id.php');
	copy('update-files/api-firebase/sections.php', '../api-firebase/sections.php');
    copy('update-files/api-firebase/send-email.php', '../api-firebase/send-email.php');
	copy('update-files/api-firebase/send-sms.php', '../api-firebase/send-sms.php');
	copy('update-files/api-firebase/settings.php', '../api-firebase/settings.php');
	copy('update-files/api-firebase/slider-images.php', '../api-firebase/slider-images.php');
	copy('update-files/api-firebase/user-addresses.php', '../api-firebase/user-addresses.php');
	copy('update-files/api-firebase/user-registration.php', '../api-firebase/user-registration.php');
	copy('update-files/api-firebase/validate-promo-code.php', '../api-firebase/validate-promo-code.php');
	copy('update-files/api-firebase/verify-token.php', '../api-firebase/verify-token.php');
	copy('update-files/api-firebase/withdrawal-requests.php', '../api-firebase/withdrawal-requests.php');
	copy('update-files/api-firebase/newsletter.php', '../api-firebase/newsletter.php');
	copy('update-files/api-firebase/faq.php', '../api-firebase/faq.php');
	copy('update-files/api-firebase/shop.php', '../api-firebase/shop.php');
	/* api-firebase ends here */

	/* api-firebase/email-templates starts here */
	copy('update-files/api-firebase/email-templates/order-receipt.php', '../api-firebase/email-templates/order-receipt.php');
    /* api-firebase/email-templates ends here */
    
    /* api-firebase/razorpay starts here */
	copy('update-files/api-firebase/razorpay/Razorpay.php', '../api-firebase/razorpay/Razorpay.php');
    /* api-firebase/razorpay ends here */


	/* delivery boy files starts */
	copy('update-files/delivery-boy/api/api-v1.php', '../delivery-boy/api/api-v1.php');
	copy('update-files/delivery-boy/api/api-v1-docs.txt', '../delivery-boy/api/api-v1-docs.txt');
	copy('update-files/delivery-boy/api/verify-token.php', '../delivery-boy/api/verify-token.php');
	copy('update-files/delivery-boy/api/send-email.php', '../delivery-boy/api/send-email.php');

	copy('update-files/delivery-boy/db-operation.php', '../delivery-boy/db-operation.php');
	copy('update-files/delivery-boy/delete-order.php', '../delivery-boy/delete-order.php');
    copy('update-files/delivery-boy/delivery-boy-profile.php', '../delivery-boy/delivery-boy-profile.php');
    copy('update-files/delivery-boy/footer.php', '../delivery-boy/footer.php');
	copy('update-files/delivery-boy/fund-transfers.php', '../delivery-boy/fund-transfers.php');
	copy('update-files/delivery-boy/get-bootstrap-table-data.php', '../delivery-boy/get-bootstrap-table-data.php');
	copy('update-files/delivery-boy/header.php', '../delivery-boy/header.php');
	copy('update-files/delivery-boy/home.php', '../delivery-boy/home.php');
	copy('update-files/delivery-boy/index.php', '../delivery-boy/index.php');
    copy('update-files/delivery-boy/invoice.php', '../delivery-boy/invoice.php');
    copy('update-files/delivery-boy/login-form.php', '../delivery-boy/login-form.php');
    copy('update-files/delivery-boy/logout.php', '../delivery-boy/logout.php');
	copy('update-files/delivery-boy/order-detail.php', '../delivery-boy/order-detail.php');
	copy('update-files/delivery-boy/orders.php', '../delivery-boy/orders.php');

	copy('update-files/delivery-boy/public/confirm-delete-order.php', '../delivery-boy/public/confirm-delete-order.php');
	copy('update-files/delivery-boy/public/fund-transfer-table.php', '../delivery-boy/public/fund-transfer-table.php');
	copy('update-files/delivery-boy/public/invoice-print.php', '../delivery-boy/public/invoice-print.php');
	copy('update-files/delivery-boy/public/orders-data.php', '../delivery-boy/public/orders-data.php');
	copy('update-files/delivery-boy/public/orders-table.php', '../delivery-boy/public/orders-table.php');

	copy('update-files/delivery-boy-play-store-privacy-policy.php', '../delivery-boy-play-store-privacy-policy.php');
	copy('update-files/delivery-boy-play-store-terms-conditions.php', '../delivery-boy-play-store-terms-conditions.php');
	copy('update-files/delivery-boy-privacy-policy.php', '../delivery-boy-privacy-policy.php');
	/* delivery boy files ends */

    /* dist files start */
	copy('update-files/dist/js/covert.js', '../dist/js/covert.js');
    copy('update-files/dist/css/AdminLTE.min.css', '../dist/css/AdminLTE.min.css');
    /* dist files end */

    /* includes files start */
	copy('update-files/includes/custom-functions.php', '../includes/custom-functions.php');
	copy('update-files/includes/firebase.php', '../includes/firebase.php');
    copy('update-files/includes/functions.php', '../includes/functions.php');
    copy('update-files/includes/push.php', '../includes/push.php');
    copy('update-files/includes/variables.php', '../includes/variables.php');
    /* includes files end */

    /* library starts here */
    copy('update-files/library/class.phpmailer.php', '../library/class.phpmailer.php');
	copy('update-files/library/class.smtp.php', '../library/class.smtp.php');
	copy('update-files/library/jwt.php', '../library/jwt.php');
	copy('update-files/library/products.csv', '../library/products.csv');
	copy('update-files/library/products.txt', '../library/products.txt');
	copy('update-files/library/update-products.csv', '../library/update-products.csv');
	copy('update-files/library/update-products.txt', '../library/update-products.txt');
	copy('update-files/library/update-variants.csv', '../library/update-variants.csv');
	copy('update-files/library/update-variants.txt', '../library/update-variants.txt');
	copy('update-files/library/variants.csv', '../library/variants.csv');
	copy('update-files/library/variants.txt', '../library/variants.txt');
	/* library ends here */

    /* manager-app-privacy-policy starts here */
    //copy('update-files/manager-app-privacy-policy/admin-app/api/api-v1.php', '../manager-app-privacy-policy/admin-app/api/api-v1.php');
    //copy('update-files/manager-app-privacy-policy/admin-app/api/api-v1-docs.txt', '../manager-app-privacy-policy/admin-app/api/api-v1-docs.txt');
    //copy('update-files/manager-app-privacy-policy/admin-app/api/verify-token.php', '../manager-app-privacy-policy/admin-app/api/verify-token.php');
    
    //copy('update-files/manager-app-privacy-policy/manager-app-play-store-privacy-policy.php', '../manager-app-privacy-policy/manager-app-play-store-privacy-policy.php');
    //copy('update-files/manager-app-privacy-policy/manager-app-play-store-terms-conditions.php', '../manager-app-privacy-policy/manager-app-play-store-terms-conditions.php');
    //copy('update-files/manager-app-privacy-policy/manager-app-privacy-policy.php', '../manager-app-privacy-policy/manager-app-privacy-policy.php');
    /* manager-app-privacy-policy ends here */

    /* midtrans starts */
    copy('update-files/midtrans/create-payment.php', '../midtrans/create-payment.php');
    copy('update-files/midtrans/midtrans.php', '../midtrans/midtrans.php');
    copy('update-files/midtrans/notification-handler.php', '../midtrans/notification-handler.php');
    copy('update-files/midtrans/payment-process.php', '../midtrans/payment-process.php');
    /* midtrans ends */

	/* paypal starts */
	copy('update-files/paypal/create-payment.php', '../paypal/create-payment.php');
	copy('update-files/paypal/data.txt', '../paypal/data.txt');
	copy('update-files/paypal/ipn.php', '../paypal/ipn.php');
	copy('update-files/paypal/payment_status.php', '../paypal/payment_status.php');
    /* paypal end */


    /* stripe starts */
	copy('update-files/stripe/create-payment.php', '../stripe/create-payment.php');
	copy('update-files/stripe/index.php', '../stripe/index.php');
	copy('update-files/stripe/payment-process.php', '../stripe/payment-process.php');
	copy('update-files/stripe/script.js', '../stripe/script.js');
	copy('update-files/stripe/stripe.php', '../stripe/stripe.php');
	copy('update-files/stripe/webhook.php', '../stripe/webhook.php');
    /* stripe end */

	/* public starts */
	copy('update-files/public/add-area-form.php', '../public/add-area-form.php');
	copy('update-files/public/add-category-form.php', '../public/add-category-form.php');
	copy('update-files/public/add-city-form.php', '../public/add-city-form.php');
	copy('update-files/public/add-image-form.php', '../public/add-image-form.php');
	copy('update-files/public/add-product-form.php', '../public/add-product-form.php');
	copy('update-files/public/add-subcategory-form.php', '../public/add-subcategory-form.php');
	copy('update-files/public/add-tax-form.php', '../public/add-tax-form.php');
	copy('update-files/public/area-table.php', '../public/area-table.php');
	copy('update-files/public/bulk-update-form.php', '../public/bulk-update-form.php');
	copy('update-files/public/bulk-upload-form.php', '../public/bulk-upload-form.php');
	copy('update-files/public/category-table.php', '../public/category-table.php');
	copy('update-files/public/city-table.php', '../public/city-table.php');
	copy('update-files/public/confirm-delete-area.php', '../public/confirm-delete-area.php');
	copy('update-files/public/confirm-delete-category.php', '../public/confirm-delete-category.php');
	copy('update-files/public/confirm-delete-city.php', '../public/confirm-delete-city.php');
	copy('update-files/public/confirm-delete-login-user.php', '../public/confirm-delete-login-user.php');
	copy('update-files/public/confirm-delete-order.php', '../public/confirm-delete-order.php');
	copy('update-files/public/confirm-delete-product.php', '../public/confirm-delete-product.php');
	copy('update-files/public/confirm-delete-query.php', '../public/confirm-delete-query.php');
	copy('update-files/public/confirm-delete-subcategory.php', '../public/confirm-delete-subcategory.php');
	copy('update-files/public/confirm-delete-tax.php', '../public/confirm-delete-tax.php');
	copy('update-files/public/customer-report-table.php', '../public/customer-report-table.php');
	copy('update-files/public/customers-table.php', '../public/customers-table.php');
	copy('update-files/public/db-operation.php', '../public/db-operation.php');
	copy('update-files/public/delete-other-images.php', '../public/delete-other-images.php');
	copy('update-files/public/delievery-charge-form.php', '../public/delievery-charge-form.php');
	copy('update-files/public/delivery-boy-table.php', '../public/delivery-boy-table.php');
	copy('update-files/public/edit-area-form.php', '../public/edit-area-form.php');
	copy('update-files/public/edit-category-form.php', '../public/edit-category-form.php');
	copy('update-files/public/edit-city-form.php', '../public/edit-city-form.php');
	copy('update-files/public/edit-image-form.php', '../public/edit-image-form.php');
	copy('update-files/public/edit-product-form.php', '../public/edit-product-form.php');
	copy('update-files/public/edit-query-form.php', '../public/edit-query-form.php');
	copy('update-files/public/edit-subcategory-form.php', '../public/edit-subcategory-form.php');
	copy('update-files/public/edit-tax-form.php', '../public/edit-tax-form.php');
	copy('update-files/public/email-send.php', '../public/email-send.php');
	copy('update-files/public/front-end-setting-form.php', '../public/front-end-setting-form.php');
    copy('update-files/public/fund-transfer-table.php', '../public/fund-transfer-table.php');
    copy('update-files/public/get-list-web-category.php', '../public/get-list-web-category.php');
	copy('update-files/public/invoice-print.php', '../public/invoice-print.php');
    copy('update-files/public/invoice-table.php', '../public/invoice-table.php');
    copy('update-files/public/login-form.php', '../public/login-form.php');
	copy('update-files/public/low-stock-products-table.php', '../public/low-stock-products-table.php');
	copy('update-files/public/manage-customer-wallet-table.php', '../public/manage-customer-wallet-table.php');
	copy('update-files/public/orders-data.php', '../public/orders-data.php');
	copy('update-files/public/orders-table.php', '../public/orders-table.php');
	copy('update-files/public/payment-requests-table.php', '../public/payment-requests-table.php');
	copy('update-files/public/privacypolicy.php', '../public/privacypolicy.php');
    copy('update-files/public/product-data.php', '../public/product-data.php');
    copy('update-files/public/product-sales-report-table.php', '../public/product-sales-report-table.php');
	copy('update-files/public/products-table.php', '../public/products-table.php');
	copy('update-files/public/products-taxes-table.php', '../public/products-taxes-table.php');
	copy('update-files/public/promo-code-table.php', '../public/promo-code-table.php');
	copy('update-files/public/purchase-code-form.php', '../public/purchase-code-form.php');
	copy('update-files/public/purchase-code-validator.php', '../public/purchase-code-validator.php');
	copy('update-files/public/reset-password.php', '../public/reset-password.php');
	copy('update-files/public/return-requests-table.php', '../public/return-requests-table.php');
	copy('update-files/public/sales-report-table.php', '../public/sales-report-table.php');
	copy('update-files/public/send-forgot-password-mail.php', '../public/send-forgot-password-mail.php');
	copy('update-files/public/send-message.php', '../public/send-message.php');
    copy('update-files/public/setting-form.php', '../public/setting-form.php');
    copy('update-files/public/social-media-table.php', '../public/social-media-table.php');
	copy('update-files/public/sold-out-products-table.php', '../public/sold-out-products-table.php');
	copy('update-files/public/subcategory-table.php', '../public/subcategory-table.php');
	copy('update-files/public/system-users-form.php', '../public/system-users-form.php');
	copy('update-files/public/time-slots-table.php', '../public/time-slots-table.php');
	copy('update-files/public/transaction-table.php', '../public/transaction-table.php');
	copy('update-files/public/units-table.php', '../public/units-table.php');
	copy('update-files/public/wallet-transactions-table.php', '../public/wallet-transactions-table.php');
	copy('update-files/public/web-category.php', '../public/web-category.php');
	copy('update-files/public/web-header-form.php', '../public/web-header-form.php');
	copy('update-files/public/withdrawal-requests-table.php', '../public/withdrawal-requests-table.php');
	/* public end */

	/* rppt files start here */
	copy('update-files/about-us.php', '../about-us.php');
	copy('update-files/add-area.php', '../add-area.php');
	copy('update-files/add-category.php', '../add-category.php');
	copy('update-files/add-city.php', '../add-city.php');
	copy('update-files/add-delivery-boy.php', '../add-delivery-boy.php');
	copy('update-files/add-image.php', '../add-image.php');
	copy('update-files/add-media.php', '../add-media.php');
	copy('update-files/add-product.php', '../add-product.php');
	copy('update-files/add-subcategory.php', '../add-subcategory.php');
	copy('update-files/add-tax.php', '../add-tax.php');
	copy('update-files/admin-profile.php', '../admin-profile.php');
	copy('update-files/api-docs.txt', '../api-docs.txt');
	copy('update-files/areas.php', '../areas.php');
	copy('update-files/bulk-update.php', '../bulk-update.php');
	copy('update-files/bulk-upload.php', '../bulk-upload.php');
	copy('update-files/categories.php', '../categories.php');
	copy('update-files/categories-order.php', '../categories-order.php');
	copy('update-files/city.php', '../city.php');
	copy('update-files/contact.php', '../contact.php');
	copy('update-files/contact-us.php', '../contact-us.php');
	copy('update-files/customer-report.php', '../customer-report.php');
	copy('update-files/customers.php', '../customers.php');
	copy('update-files/delete-area.php', '../delete-area.php');
	copy('update-files/delete-category.php', '../delete-category.php');
	copy('update-files/delete-city.php', '../delete-city.php');
	copy('update-files/delete-order.php', '../delete-order.php');
	copy('update-files/delete-product.php', '../delete-product.php');
	copy('update-files/delete-query.php', '../delete-query.php');
	copy('update-files/delete-subcategory.php', '../delete-subcategory.php');
	copy('update-files/delete-tax.php', '../delete-tax.php');
	copy('update-files/delieverycharge.php', '../delieverycharge.php');
	copy('update-files/delivery-boy-play-store-privacy-policy.php', '../delivery-boy-play-store-privacy-policy.php');
	copy('update-files/delivery-boy-play-store-terms-conditions.php', '../delivery-boy-play-store-terms-conditions.php');
	copy('update-files/delivery-boy-privacy-policy.php', '../delivery-boy-privacy-policy.php');
	copy('update-files/delivery-boys.php', '../delivery-boys.php');
	copy('update-files/edit-area.php', '../edit-area.php');
	copy('update-files/edit-category.php', '../edit-category.php');
	copy('update-files/edit-city.php', '../edit-city.php');
	copy('update-files/edit-image.php', '../edit-image.php');
	copy('update-files/edit-product.php', '../edit-product.php');
	copy('update-files/edit-query.php', '../edit-query.php');
	copy('update-files/edit-subcategory.php', '../edit-subcategory.php');
	copy('update-files/edit-tax.php', '../edit-tax.php');
	copy('update-files/email.php', '../email.php');
    copy('update-files/faq.php', '../faq.php');
    copy('update-files/footer.php', '../footer.php');
	copy('update-files/forgot-password.php', '../forgot-password.php');
	copy('update-files/front-end-settings.php', '../front-end-settings.php');
	copy('update-files/fund-transfers.php', '../fund-transfers.php');
	copy('update-files/header.php', '../header.php');
	copy('update-files/home.php', '../home.php');
	copy('update-files/index.php', '../index.php');
	copy('update-files/info.php', '../info.php');
	copy('update-files/invoice.php', '../invoice.php');
	copy('update-files/invoices.php', '../invoices.php');
    copy('update-files/loginusers.php', '../loginusers.php');
    copy('update-files/logout.php', '../logout.php');
	copy('update-files/low-stock-products.php', '../low-stock-products.php');
	copy('update-files/main-slider.php', '../main-slider.php');
	copy('update-files/manage-customer-wallet.php', '../manage-customer-wallet.php');
	copy('update-files/manager-app-play-store-privacy-policy.php', '../manager-app-play-store-privacy-policy.php');
	copy('update-files/manager-app-play-store-terms-conditions.php', '../manager-app-play-store-terms-conditions.php');
	copy('update-files/manager-app-privacy-policy.php', '../manager-app-privacy-policy.php');
    copy('update-files/media.php', '../media.php');
	copy('update-files/new-offers.php', '../new-offers.php');
	copy('update-files/notification.php', '../notification.php');
	copy('update-files/notification-settings.php', '../notification-settings.php');
	copy('update-files/order-detail.php', '../order-detail.php');
	copy('update-files/orders.php', '../orders.php');
	copy('update-files/payment-methods-settings.php', '../payment-methods-settings.php');
	copy('update-files/payment-requests.php', '../payment-requests.php');
	copy('update-files/play-store-privacy-policy.php', '../play-store-privacy-policy.php');
	copy('update-files/privacy-policy.php', '../privacy-policy.php');
	copy('update-files/product-detail.php', '../product-detail.php');
    copy('update-files/products.php', '../products.php');
	copy('update-files/product-sales-report.php', '../product-sales-report.php');
	copy('update-files/products-order.php', '../products-order.php');
	copy('update-files/products-taxes.php', '../products-taxes.php');
	copy('update-files/promo-code.php', '../promo-code.php');
	copy('update-files/purchase-code.php', '../purchase-code.php');
	copy('update-files/reset-password.php', '../reset-password.php');
	copy('update-files/return-requests.php', '../return-requests.php');
	copy('update-files/sales-report.php', '../sales-report.php');
	copy('update-files/sections.php', '../sections.php');
	copy('update-files/send-multiple-push.php', '../send-multiple-push.php');
	copy('update-files/settings.php', '../settings.php');
	copy('update-files/social-media.php', '../social-media.php');
	copy('update-files/sold-out-products.php', '../sold-out-products.php');
	copy('update-files/subcategories.php', '../subcategories.php');
	copy('update-files/system-users.php', '../system-users.php');
	copy('update-files/terms-conditions.php', '../terms-conditions.php');
	copy('update-files/time-slots.php', '../time-slots.php');
	copy('update-files/transaction.php', '../transaction.php'); 
	copy('update-files/units.php', '../units.php'); 
	copy('update-files/view-category-product.php', '../view-category-product.php');
	copy('update-files/view-city-area.php', '../view-city-area.php');
	copy('update-files/view-product.php', '../view-product.php');
	copy('update-files/view-product-variants.php', '../view-product-variants.php');
	copy('update-files/view-subcategory.php', '../view-subcategory.php');
	copy('update-files/view-subcategory-product.php', '../view-subcategory-product.php');
	copy('update-files/wallet-transactions.php', '../wallet-transactions.php');
	copy('update-files/web-category.php', '../web-category.php');
	copy('update-files/web-header.php', '../web-header.php');
	copy('update-files/withdrawal-requests.php', '../withdrawal-requests.php');
	/* root files end here */

	echo "Congratulations! You have successfully upgraded your system!<br/><h4>If you liked our Auto Update system</h4>";

	$_SESSION['count'] = "applied";
	echo "Operation done successfully! Do not perform this second time! ";
} else {

	exit("Operation already applied! Cannot perform this second time! Please now delete the <b>/update</b> folder from your server directory");
}
